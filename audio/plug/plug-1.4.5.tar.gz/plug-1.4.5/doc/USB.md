# Known USB devices

| Device         | VID  | PID  | Note |
|----------------|:----:|:----:|------|
| **v1**         |      |      |      |
| Mustang I      | 1ed8 | 0004 |      |
| Mustang II     | 1ed8 | 0004 |      |
| Mustang III    | 1ed8 | 0005 |      |
| Mustang IV     | 1ed8 | 0005 |      |
| Mustang V      | 1ed8 | 0005 |      |
| Mustang Bronco | 1ed8 | 000a |      |
| Mustang Mini   | 1ed8 | 0010 |      |
| Mustang Floor  | 1ed8 | 0012 |      |
| **v2**         |      |      |      |
| Mustang I      | 1ed8 | 0014 |      |
| Mustang II     | 1ed8 | 0014 |      |
| Mustang III    | 1ed8 | 0016 |      |
| Mustang IV     | 1ed8 | 0016 |      |
| Mustang V      | 1ed8 | 0016 |      |


## Other devices

| Device         | VID  | PID  | Note |
|----------------|:----:|:----:|------|
| Mustang LT 25  | 1ed8 | 0037 |      |
| Mustang LT 40S | 1ed8 | 0046 |      |
| Rumble LT 25   | 1ed8 | 0038 |      |
