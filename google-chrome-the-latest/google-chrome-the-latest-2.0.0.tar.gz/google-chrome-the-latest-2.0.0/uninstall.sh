#!/bin/bash

rm -rf /opt/google-chrome-the-latest
rm /etc/cron.hourly/google-chrome-the-latest-cron.sh
