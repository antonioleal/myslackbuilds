wxformbuilder for Debian
-----------------------

<possible notes regarding this package - if none, delete this file>

 -- Steffen Olszewski <steffen.olszewski@gero-mess.de>  Sat, 25 Sep 2021 00:53:01 +0200
