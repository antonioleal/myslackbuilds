var searchData=
[
  ['boolattribute_0',['BoolAttribute',['../classtinyxml2_1_1_x_m_l_element.html#a53eda26131e1ad1031ef8ec8adb51bd8',1,'tinyxml2::XMLElement']]],
  ['booltext_1',['BoolText',['../classtinyxml2_1_1_x_m_l_element.html#a68569f59f6382bcea7f5013ec59736d2',1,'tinyxml2::XMLElement']]],
  ['boolvalue_2',['BoolValue',['../classtinyxml2_1_1_x_m_l_attribute.html#a98ce5207344ad33a265b0422addae1ff',1,'tinyxml2::XMLAttribute']]],
  ['buffer_3',['Parse an XML from char buffer',['../_example_2.html',1,'']]]
];
