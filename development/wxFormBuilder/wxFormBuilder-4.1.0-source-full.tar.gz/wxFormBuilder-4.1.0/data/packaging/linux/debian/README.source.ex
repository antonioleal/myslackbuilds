wxformbuilder for Debian
-----------------------

<this file describes information about the source package, see Debian policy
manual section 4.14. You WILL either need to modify or delete this file>



 -- Steffen Olszewski <steffen.olszewski@gero-mess.de>  Sat, 25 Sep 2021 00:53:01 +0200

