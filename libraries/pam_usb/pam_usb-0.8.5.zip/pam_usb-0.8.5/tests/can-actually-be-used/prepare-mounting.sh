#!/usr/bin/bash

set -e

sudo modprobe dummy-hcd is_high_speed=1
