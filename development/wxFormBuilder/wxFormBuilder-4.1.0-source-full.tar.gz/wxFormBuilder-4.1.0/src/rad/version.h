#ifndef RAD_VERSION_H
#define RAD_VERSION_H

const char* getVersion();

#endif  // RAD_VERSION_H
