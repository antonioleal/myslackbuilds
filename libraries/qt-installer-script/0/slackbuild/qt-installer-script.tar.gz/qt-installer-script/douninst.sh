rm -rf /opt/qt-installer-script
