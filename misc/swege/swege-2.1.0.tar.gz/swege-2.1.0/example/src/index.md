
swege is a Static WEbsite GEnerator written in C.

It leverages the [discount](http://www.pell.portland.or.us/~orc/Code/discount/)
library for generating a website from a set of Markdown files.

# FEATURES
* Under 300 lines of C (without counting external libraries).
* Incremental updates.
* Pretty fast!
* Almost no dependencies except for discount.
* Portable-ish (*nix at least).


### Example pages:

* [Lorem Ipsum](posts/lorem.html)
* [Different ways to generate a title](posts/title.html)
