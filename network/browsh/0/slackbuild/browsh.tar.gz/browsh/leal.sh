#!/bin/bash

# upx nodejs  (go sakado)

PKG=browsh
VERSION=1.8.3

cw=$(pwd)
export GOPATH=$cw/go
mkdir -p $GOPATH
interfacer="${GOPATH}/src/github.com/browsh-org/${PKG}/interfacer"
mkdir -p "${GOPATH}/src/github.com/browsh-org/${PKG}"
rm -rf ${interfacer}

# ln -s  "../../../../../${PKG}-${VERSION}/interfacer" "${interfacer}"

# ln -sf interfacer "${interfacer}"
# cp "${PKG}-${VERSION}.xpi" "${interfacer}/src/${PKG}/${PKG}.xpi"

mkdir -p "${interfacer}/src/${PKG}"
cp "${PKG}-${VERSION}.xpi" interfacer/src/browsh/browsh.xpi

cd interfacer
webextension="src/browsh/browsh.xpi"

/home/antonio/Downloads/go/bin/go build	-x -modcacherw \
            -gcflags "all=-trimpath=${GOPATH}"\
            -asmflags "all=-trimpath=${GOPATH}"\
                -o "${cw}/${PKG}" ./cmd/browsh
# strip --strip-all "${srcdir}/${PKG}"
# if [ $(which upx 2>/dev/null) ]; then
#     echo Compressing ${PKG} with UPX...
#     upx "${srcdir}/${PKG}"; fi


