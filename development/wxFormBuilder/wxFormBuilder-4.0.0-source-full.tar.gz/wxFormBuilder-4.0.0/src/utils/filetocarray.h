#ifndef UTILS_FILETOCARRAY_H
#define UTILS_FILETOCARRAY_H

#include <wx/string.h>


class FileToCArray
{
public:
    static wxString Generate(const wxString& sourcepath);
};

#endif  // UTILS_FILETOCARRAY_H
