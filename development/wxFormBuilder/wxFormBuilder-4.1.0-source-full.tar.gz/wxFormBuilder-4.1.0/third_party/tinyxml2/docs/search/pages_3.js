var searchData=
[
  ['char_20buffer_0',['Parse an XML from char buffer',['../_example_2.html',1,'']]]
];
