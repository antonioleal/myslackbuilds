<p align="center">
<img src="media/zeroscripts.png"  alt="Silk" style="width:33%; height:auto;"/>
</p>

## The Zero Scripts Setup

*This folder contains a simple set of auxiliary scripts that simplify the process of collaborating with SlackBuilds.org*

---

### First and Foremost
Before installing please create a GitHub.com account and do the following three steps:
1. In your area, create an empty repository called (exactly) 'myslackbuilds'. Check github policy (account key, etc..) so you are able to commit to your own repository.

2. Still in your github account, create a classic Personal Access Token (PAT) by navigating to your **Settings** via the profile menu, then select **«<> Developer settings»** and then **«Personal access tokens»**.  Choose Tokens (classic) and click Generate new token (classic). Assign a descriptive Note, set an Expiration date, and select the required Scopes (permissions) for the token.  Finally, click Generate token and copy the token immediately, as it will not be displayed again. Never share you PAT!!

3. Open your web-browser and go to https://github.com/SlackBuildsOrg/slackbuilds. Clone this repository, so that your copy is called (exactly) 'slackbuilds'. 

### Obtaining the 0scripts
To obtain the 0scripts you can just download them from this repo as a zip file. A SlackBuild package will be soon available also on my own 'myslackbuilds', but for now just download the zip archive.

Run **install.sh** to copy the scripts to the correct locations:
```
/usr/bin
/usr/share/0scritps
```

**uninstall.sh** will remove the 0scripts from your machine. 


### Setup
A script called 0setup is provided to prepare the initial environment and the auxiliary packages described below, the explanation is necessary for your understanding of how things work.

0setup will check if dependencies are available and otherwise install:

* the package `sbo-maintainer-tools` available from SlackBuilds.org

* the package `github-cli` available from SlackBuilds.org

* the package `jq` available from SlackBuilds.org

* the package `meld` available from SlackBuilds.org

* the package `xarchiver` available from SlackBuilds.org

Afterwards 0setup will create a *wokspace* folder '$HOME/slackware-builds' folder and inside it will clone 'myslackbuilds' and 'slackbuilds', after asking for your github **account name** and **PAT token**. 

Inside "myslackbuilds" you must follow strictly the organization of categories from SlackBuilds.org.
>For example: The **plus42.SlackBuild** and all associated files, *.info, desc, etc.. are stored at `academic/plus42`, so your folder for this SlackBuild should be:
> `$HOME/slackware-builds/myslackbuilds/academic/plus42`

Note: the plus42 SlackBuild is provided as an example you can install with 0setup. Study it.

0setup will also create a configuration file at "$HOME/.config/0scriptsrc" that you should edit and adapt to your needs.

Your 'myslackbuilds' should have a similar structure to 'slackbuilds' but naturally with much less SlackBuilds, or none at all if you are just starting.

The complete work environment should look like this:

        ~/slackware-builds/
        
            myslackbuilds/
                .git
                 academic/plus42/       <- your plus42 scripts go here
                 academic/plus42/0/     <- place whatever you want here
                 (...etc...)
                 desktop/my_great_new_slackbuild  <- in "desktop", for ex.
                
             slackbuilds                <- your fork of slackbuilds
                .git
                 academic/3D-ICE/
                 academic/celestia/
                 academic/plus42/
                 desktop/thunar-sendto-clamtk
                 (...etc...)
        
             otherbuilds
                 some_test_or_slackbuild_or_whatever/
                 (...etc...)
    


... and you are ready to go!

### The menu
A simple menu describing the complete workflow and helping with the build sequence is provided in the **0** script (which you can invoke by just typing "**0**" also). You need to run it from within your slackbuild folder.

### The scripts
With a few exceptions the zero scripts are meant to be started from the slackbuild directory. Inside the slackbuild directory a folder named "0" also exists where you can store any additional files or notes you need to help you maintain your slackbuild. Have a look at my own setup.

Example:
```
cd ~/slackware-builds/myslackbuilds/academic/plus42
0tar
0pull-request
```
will create a branch and issue a PR to github.com/SlackBuildsOrg/slackbuilds 

#### Current scripts

    Script: 0auto-crawler
    Effect: Check a multitude of sites to know if new versions are available.
            But you need to provide an updater script. See my examples.
            Notice you are web-crawling so use this with care.

    Script: 0build
    Effect: Starts the build process.

    Script: 0clean-tree
    Effect: if you also placed myslackbuilds directory in github (like me!)
            then this deletes all non-git controlled files.

    Script: 0commit-push
    Effect: Runs 0make-readme, commits and pushes your changes to your github repo.

    Script: 0delete-branches
    Effect: Each Saturday afternoon, you can run this to delete all braches you
            created with the script 0pull-request.

    Script: 0download-source-tarballs
    Effect: Downloads the sources referred in the *.info file. It also
            checks if MD5SUM(s) are correct in the infor file, use together
            with 0print-tarball-md5sums to prepare a new *.info file.

    Script: 0lspkg
    Effect: A Slackware tool which simply lists the currently installed
            packages.
            see http://www.linuxquestions.org/questions/showthread.php?postid=899459#post899459

    Script: 0make-missing-readmes
    Effect: if you also placed myslackbuilds directory in github (like me!)
            then this automatically generates a README.md for github.

    Script: 0make-readme
    Effect: if you also placed myslackbuilds directory in github (like me!)
            then this automatically generates a README.md for github.

    Script: 0make-updater
    Effect: This command will create the "updater" script, as well as two templates
            based on *.info and *.SlackBuild files:
                    <your slackbuild folder>/0/updater
                    <your slackbuild folder>/0/version
                    <your slackbuild folder>/0/template/<program>.info.template
                    <your slackbuild folder>/0/template/<program>.SlackBuild.template
            You need to carefully check what the updater is doing and test if it can
            recreate your current version of SlackBuild. To do that write some string
            inside the 0/version file, for ex "1234", run the updater andheck the
            resulting new *.info and *.SlackBuild using git --diff.

    Script: 0meld
    Effect: Compares what is currently published in slackbuilds.org (your local folder!)
            with your current script. You need the meld program.

    Script: 0pkginfo
    Effect: A Slackware tool to find the inforamtion about any installed 
            package
            see http://www.linuxquestions.org/questions/showthread.php?postid=899459#post899459

    Script: 0pull-request
    Effect: Makes a PR to github.com/SlackBuildsOrg/slackbuilds.

    Script: 0replace-string
    Effect: This uses sed to replace one string for another in your whole slackbuild scripts.
            Very useful, but use with care.

    Script: 0reset
    Effect: Resets & cleans myslackbuilds and if parameter "all" is specified also your
            slackbuilds clone folder.

    Script: 0setup
    Effect: Run once to setup your slack-builds '0' environment.

    Script: 0slackware-binary-dependencies
    Effect: Inspect a binary file and check discover its package dependencies.

    Script: 0takeover
    Effect: copies and modifies a SlackBuild from "slackbuilds" to "myslackbuilds"
            so that it is prepared for you to takeover its maintenance.
            Your need to edit YOURNAME, YOUREMAIL and YOURCOPYRIGHT variables
            in the 0takeover script, unless you want to use mine ;-)

    Script: 0tar
    Effect: creates a "slackbuild".tar.gz pack ready to be submitted on the
            folder 0/slackbuild under the SlackBuild you are working.
            This step is needed before you run 0commit-push

    Script: 0update-md5-info
    Effect: Reads the source(s) in *.info file, calculates new MD5SUM(s) and   
            produces a new *.info file.

    Script: 0whichpkg
    Effect: A Slackware tool to find which package a file comes from.
            see http://www.linuxquestions.org/questions/showthread.php?postid=899459#post899459


### Workflows

If you are in Europe SlackBuilds.org public updates occur each Saturday, usually in the morning. So your workflow would be something like the one described here.

##### I. "During the week":
1. Check if new sources are available upstream for each of your packages.
    * Better still: subscribe to be notified when this occurs!

2. Check if any slackbuild maintainer has modified your script. Sometimes they do! Use **0meld** to compare your current script with the published one.

3. Once a new source is available update the *.info file and point DOWNLOAD and DOWNLOAD_x86_64 to the new source tarballs on the web.
   * Afterwards **0download-source-tarballs** and **0update-md5-info** are your friends.

4. Update your *.SlackBuild script
    * Sometimes is just a matter of upgrading the version number, but upstream developers sometimes change formats.
    * **0replace-string** is your friend.
    * If you patched the original sources make sure these mods are still applicable.

5. Build the source with **0build** saying 'yes' to all the steps.
    * The build package will be in /tmp as usual.
    * A new compressed `'package'.tar.gz` will be created in 0/slackbuild sub-folders of your SlackBuild. You can also use **0tar** for this.

6. Test you new build.
    * It is a good idea to install your new software in a "clean" setup. If possible use a virtual machine.
    * If your tests are successful then you are ready to publish your work.

7. If this is a second submission of an existing SlackBuild you can create a Pull Request (PR) with **0pull-request**
    * Go to the github.com/SlackBuildsOrg/slackbuilds and confirm the PR.

    Otherwise, for first submissions, (totally new SlackBuild scripts) you have to use the SlackBuilds.org site and manually upload your work.

8. Periodically check github.com/SlackBuildsOrg/slackbuilds to see if you work has been approved, or rejected by some reason.
    * Its is a very good idea to subscribe to the `slackbuilds-users` and `slackbuilds-devel` mailling lists so you are aware of what other people are doing. You can also ask for specific help regarding your scripts or get the "maintainer" status for new ones.

##### II. "Saturday afternoon":
1. Once your scripts are released to the public go to `https://github.com/{your account}/slackbuilds` and synchronize your fork with the upstream master. Better still: this can be done by running **0reset all** which also deletes unneeded tarballs and other trash. Also **0reset all** can be run at any time to clean your workspace.

2. Delete accessory branches by running **0delete-branches all**

3. That's it. Now you are ready to restart the workflow.

##### III. (Optional) Go the easy way, use an "updater":
Eventually you'll end up with a bigger number of SlackBuilds to maintain. This is where and "updater" becomes usefull.<br>
An "updater" is basically a script that:
1. checks if a new version of your program is available upstream
2. is able to upgrade the *.info and *.SlackBuild files, or any other required file.
3. downloads the new sources

All in time for you to **build** and **test** if the new program version is functional.

In order to create an updater you can use **0make-updater** which will create a draft of the script for you to change.<br>
All updaters can be invoked "in bulk" using **0auto-updater**.

See my examples of updater scripts, compare a few and notice they are all very similar...

<br><b>
#### Happy Slacking!
António Leal
